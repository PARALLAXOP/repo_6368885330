package com.pubgm.floating;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.Settings;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;

import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.widget.SwitchCompat;
import com.pubgm.R;

import com.pubgm.floating.HideRecorder;
import com.pubgm.floating.ToggleAim;
import com.pubgm.floating.ToggleBullet;
import com.pubgm.floating.ToggleSimulation;
import com.pubgm.utils.Animations;
import com.pubgm.utils.FLog;
import com.pubgm.utils.FPrefs;
import java.io.FileNotFoundException;
import static java.lang.System.exit;
import android.graphics.drawable.GradientDrawable;
import java.io.InputStream;
import android.widget.Toast;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class FloatLogo extends Service implements View.OnClickListener {

    private WindowManager mWindowManager;
    private View mFloatingView;
    View espView,logoView;
    
    static {
        try {
            System.loadLibrary("client");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    public FPrefs getPref() {
        return FPrefs.with(this);
    }
    
    @SuppressLint("CutPasteId")
    @Override
    public void onCreate() {
        super.onCreate();
        createOver();
        logoView = mFloatingView.findViewById(R.id.relativeLayoutParent);
        espView = mFloatingView.findViewById(R.id.espView);
        Init();
    }

    private void DrawESP() {
        startService(new Intent(this, Overlay.class));
    }
    
    private void StopESP() {
        stopService(new Intent(this, Overlay.class));
    }
    
    private void StartAimTouch() {
        startService(new Intent(getApplicationContext(), ToggleSimulation.class));
    }

    private void StopAimTouch() {
        stopService(new Intent(getApplicationContext(), ToggleSimulation.class));
    }

    private void StartAimFloat() {
        startService(new Intent(getApplicationContext(), ToggleAim.class));
    }

    private void StopAimFloat() {
        stopService(new Intent(getApplicationContext(), ToggleAim.class));
    }

    private void StartAimBulletFloat() {
        startService(new Intent(getApplicationContext(), ToggleBullet.class));
    }

    private void StopAimBulletFloat() {
        stopService(new Intent(getApplicationContext(), ToggleBullet.class));
    }
    

    @SuppressLint("InflateParams")
    void createOver(){
        //getting the widget layout from xml using layout inflater
        mFloatingView = LayoutInflater.from(this).inflate(R.layout.float_logo, null);
        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        }
        
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,LAYOUT_FLAG,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.RGBA_8888
        );
        
        if (getPref().readBoolean("anti_recorder")) {
			HideRecorder.setFakeRecorderWindowLayoutParams(params);
        }
        
        //getting windows services and adding the floating view to it
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);
        final GestureDetector gestureDetector = new GestureDetector(this, new SingleTapConfirm());

        //window funclion
        TextView closeBtn=mFloatingView.findViewById(R.id.closeBtn);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                espView.setVisibility(View.GONE);
                logoView.setVisibility(View.VISIBLE);
                Animations.flash(closeBtn);
            }
        });


        final LinearLayout player =mFloatingView.findViewById(R.id.players);
        final LinearLayout aimbot =mFloatingView.findViewById(R.id.aimbots);
        final LinearLayout memory =mFloatingView.findViewById(R.id.memory);
        final TextView playerBtn=mFloatingView.findViewById(R.id.playerBtn);
        final TextView aimbotBtn=mFloatingView.findViewById(R.id.aimbotBtn);
        final TextView otherBtn=mFloatingView.findViewById(R.id.otherBtn);
        
        GradientDrawable gradientDrawable1 = new GradientDrawable();
        gradientDrawable1.setColor(Color.parseColor("#FF732DC4")); // Set fill color
        gradientDrawable1.setStroke(0, Color.WHITE); // Set stroke width to 0
        gradientDrawable1.setCornerRadius(20); // Set corner radius if needed
        
						
        playerBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
                Animations.animateClick(v);
				GradientDrawable gradientDrawable1 =new GradientDrawable();
				gradientDrawable1.setStroke(0,Color.WHITE);
				gradientDrawable1.setColor(Color.parseColor("#FF732DC4"));
				gradientDrawable1.setCornerRadius(20);
				GradientDrawable gradientDrawable2 =new GradientDrawable();
				gradientDrawable2.setStroke(0,Color.TRANSPARENT);
				gradientDrawable2.setColor(Color.parseColor("#ffe4e4e4"));
				gradientDrawable2.setCornerRadius(20);
				playerBtn.setBackground(gradientDrawable1);
				aimbotBtn.setBackground(gradientDrawable2);
                otherBtn.setBackground(gradientDrawable2);
                playerBtn.setTextColor(Color.parseColor("#ff5ee863")); 
                aimbotBtn.setTextColor(Color.BLACK);
                otherBtn.setTextColor(Color.BLACK);
				player.setVisibility(View.VISIBLE);
				aimbot.setVisibility(View.GONE);
                memory.setVisibility(View.GONE);
			}
		});
			
		aimbotBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
                Animations.animateClick(v);
				GradientDrawable gradientDrawable1 =new GradientDrawable();
				gradientDrawable1.setStroke(0,Color.WHITE);
				gradientDrawable1.setColor(Color.parseColor("#FF732DC4"));
				gradientDrawable1.setCornerRadius(20);
				GradientDrawable gradientDrawable2 =new GradientDrawable();
				gradientDrawable2.setStroke(0,Color.TRANSPARENT);
				gradientDrawable2.setColor(Color.parseColor("#ffe4e4e4"));
				gradientDrawable2.setCornerRadius(20);
				playerBtn.setBackground(gradientDrawable2);
				aimbotBtn.setBackground(gradientDrawable1);
                otherBtn.setBackground(gradientDrawable2);
                playerBtn.setTextColor(Color.BLACK);
                aimbotBtn.setTextColor(Color.parseColor("#ff5ee863")); 
                otherBtn.setTextColor(Color.BLACK);
				player.setVisibility(View.GONE);
				aimbot.setVisibility(View.VISIBLE);
                memory.setVisibility(View.GONE);
			}
		});

        otherBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
                Animations.animateClick(v);
				GradientDrawable gradientDrawable1 =new GradientDrawable();
				gradientDrawable1.setStroke(0,Color.WHITE);
				gradientDrawable1.setColor(Color.parseColor("#FF732DC4"));
				gradientDrawable1.setCornerRadius(20);
				GradientDrawable gradientDrawable2 =new GradientDrawable();
				gradientDrawable2.setStroke(0,Color.TRANSPARENT);
				gradientDrawable2.setColor(Color.parseColor("#ffe4e4e4"));
				gradientDrawable2.setCornerRadius(20);
				playerBtn.setBackground(gradientDrawable2);
				aimbotBtn.setBackground(gradientDrawable2);
                otherBtn.setBackground(gradientDrawable1);
                playerBtn.setTextColor(Color.BLACK);
                aimbotBtn.setTextColor(Color.BLACK);
                otherBtn.setTextColor(Color.parseColor("#ff5ee863")); 
				player.setVisibility(View.GONE);
				aimbot.setVisibility(View.GONE);
                memory.setVisibility(View.VISIBLE);
			}
		});
        
        //floating window setting
        mFloatingView.findViewById(R.id.relativeLayoutParent).setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (gestureDetector.onTouchEvent(event)) {
                    espView.setVisibility(View.VISIBLE);
                    logoView.setVisibility(View.GONE);
                    return true;
                } else {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = params.x;
                            initialY = params.y;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            Animations.buttonPressEffect(v);
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            //this code is helping the widget to move around the screen with fingers
                            params.x = initialX + (int) (event.getRawX() - initialTouchX);
                            params.y = initialY + (int) (event.getRawY() - initialTouchY);
                            mWindowManager.updateViewLayout(mFloatingView, params);
                            Animations.buttonReleaseEffect(v);
                        return true;
                    }
                    return false;
                }
            }
        });
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mFloatingView != null) mWindowManager.removeView(mFloatingView);
    }
    
    private void ExecuteElf() {
        try {
            Runtime.getRuntime().exec("su -c", null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void ExecuteElf(java.lang.String p0) {}
    
    public void Execute(String path) {
        try {
            ExecuteElf("chmod 777 " + getFilesDir() + path);//VIRTUAL
            ExecuteElf(getFilesDir() + path);
            ExecuteElf("su -c chmod 777 " + getFilesDir() + path);//ROOT
            ExecuteElf("su -c " + getFilesDir() + path);
        } catch (Exception e) {
        }
    }

    @Override
    public void onClick(View v) {}

    boolean getConfig(String key) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getBoolean(key, false);
    }

    private int getFps() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("fps", 100);
    }

    private void setFps(int fps) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("fps", fps);
        ed.apply();
    }

    private void setValue(String key, boolean b) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(key, b);
        ed.apply();

    }

    private void setradarSize(int radarSize) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("radarSize", radarSize);
        ed.apply();
    }

    private int getradarSize() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("radarSize", 0);
    }

    private int getrangeAim() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getrangeAim", 0);
    }

    private void getrangeAim(int getrangeAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getrangeAim", getrangeAim);
        ed.apply();
    }

    private int getDistances() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("Distances", 0);
    }

    private void setDistances(int Distances) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("Distances", Distances);
        ed.apply();
    }

    private int getrecoilAim() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getrecoilAim", 0);
    }

    private void getrecoilAim(int getrecoilAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getrecoilAim", getrecoilAim);
        ed.apply();
    }

    private int getrecoilAim2() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getrecoilAim2", 0);
    }

    private void getrecoilAim2(int getrecoilAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getrecoilAim2", getrecoilAim);
        ed.apply();
    }

    private int getrecoilAim3() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getrecoilAim2", 0);
    }

    private void getrecoilAim3(int getrecoilAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getrecoilAim2", getrecoilAim);
        ed.apply();
    }

    private int getbulletspeedAim() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getbulletspeedAim", 0);
    }

    private void getbulletspeedAim(int getbulletspeedAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getbulletspeedAim", getbulletspeedAim);
        ed.apply();
    }

    private int getwideview() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getwideview", 0);
    }

    private void getwideview(int getwideview) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getwideview", getwideview);
        ed.apply();
    }

    void setTouchSize(int touchsize) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("touchsize", touchsize);
        ed.apply();
    }

    int getTouchSize() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("touchsize", 600);
    }

    void setTouchPosX(int posX) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("posX", posX);
        ed.apply();
    }

    int getTouchPosX() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("posX", 650);
    }

    void setTouchPosY(int posY) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("posY", posY);
        ed.apply();
    }

    int getTouchPosY() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("posY", 1400);
    }

    private boolean getConfigitem(String key, boolean a) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getBoolean(key, a);
    }

    private void setConfigitem(String a, boolean b) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(a, b);
        ed.apply();
    }

    private int getEspValue(String a, int b) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt(a, b);
    }

    private void setEspValue(String a, int b) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(a, b);
        ed.apply();
    }

    private int getAimSpeed() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("AimingSpeed", 18);
    }

    private void setAimSpeed(int AimingSpeed) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("AimingSpeed", AimingSpeed);
        ed.apply();
    }

    private int getSmoothness() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("smoothness", 20);
    }

    private void setSmoothness(int smoothness) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("smoothness", smoothness);
        ed.apply();
    }

    public void Hide(){
        stopSelf();
        exit(-1);
    }
    
    void setupSeekBar(final SeekBar seekBar ,final TextView textView, final int initialValue, final Runnable onChangeFunction) {
        seekBar.setProgress(initialValue);
        textView.setText(String.valueOf(initialValue));
        onChangeFunction.run();
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textView.setText(String.valueOf(progress));
                onChangeFunction.run();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

	private void EspVisual(int id, int index) {
		SwitchCompat sw = mFloatingView.findViewById(id);
		sw.setChecked(getConfig(sw.getText().toString()));
		SettingValue(index, sw.isChecked());
		sw.setOnCheckedChangeListener((btn, isChecked) -> {
			setValue(sw.getText().toString(), isChecked);
			SettingValue(index, isChecked);
		});
	}
    
    private void MemoryHack(int id, int code) {
		SwitchCompat sw = mFloatingView.findViewById(id);
		boolean val = getConfig((String) sw.getText());
		sw.setChecked(val);
		SettingMemory(code, val);
		sw.setOnCheckedChangeListener((buttonView, isChecked) -> {
		//	setValue(String.valueOf(sw.getText()), isChecked);
			SettingMemory(code, isChecked);
		});
	}
    
    void Init(){
        
        final TextView EnableEsp = mFloatingView.findViewById(R.id.EnableEsp);
		final boolean[] isChecked = {false}; 
		EnableEsp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				isChecked[0] = !isChecked[0];
				if (isChecked[0]) {
					DrawESP();
                    Animations.animateTextColor(EnableEsp, Animations.getColor("#ff5ee863"),  Animations.getColor("#ffff0000"), Animations.DURATION_MEDIUM);
                    Animations.successAnimation(EnableEsp);
					EnableEsp.setText("ESP Enabled");
				} else {
					StopESP();
                    Animations.animateTextColor(EnableEsp, Animations.getColor("#FFFF0000"),  Animations.getColor("#ff5ee863"), Animations.DURATION_MEDIUM);
                    Animations.successAnimation(EnableEsp);
					EnableEsp.setText("ESP Disabled");
				}
			}
		});
        
        final TextView isLogoBypass = mFloatingView.findViewById(R.id.isLogoBypass);
		final boolean[] isLogo = {false}; 
		isLogoBypass.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				isLogo[0] = !isLogo[0];
				if (isLogo[0]) {
					Execute("/LogoBypass 1216");
                    Execute("/LogoBypass 1520");
                    Execute("/LogoBypass 1728");
                    Animations.pulse(isLogoBypass);
					isLogoBypass.setText("  Logo Bypass On Successfully");
				} else {
					Execute("/LogoBypass 1216");
                    Execute("/LogoBypass 1520");
                    Execute("/LogoBypass 1728");
                    Animations.pulse(isLogoBypass);
					isLogoBypass.setText("  Logo Bypass on in Krafton");
				}
			}
		});
        
        
        final TextView isLobbyBypass = mFloatingView.findViewById(R.id.isLobbyBypass);
		final boolean[] isLobby = {false}; 
		isLobbyBypass.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				isLobby[0] = !isLobby[0];
				if (isLobby[0]) {
                    Execute("/LobbyBypass 1216");
                    Execute("/LobbyBypass 1520");
                    Execute("/LobbyBypass 1728");
                    Animations.pulse(isLobbyBypass);
					isLobbyBypass.setText("  Lobby Bypass On Successfully");
				} else {
					Execute("/LobbyBypass 1216");
                    Execute("/LobbyBypass 1520");
                    Execute("/LobbyBypass 1728");
                    Animations.pulse(isLobbyBypass);
					isLobbyBypass.setText("  Lobby Bypass On in Lobby");
				}
			}
		});
        
        EspVisual(R.id.isBox, 1);
		EspVisual(R.id.isLine, 2);
		EspVisual(R.id.isDist, 3);
		EspVisual(R.id.isHealth, 4);
		EspVisual(R.id.isName, 5);
		EspVisual(R.id.isHead, 6);
		EspVisual(R.id.is360Alert, 7);
		EspVisual(R.id.isSkeleton, 8);
		EspVisual(R.id.isGrenadeWarning, 9);
		EspVisual(R.id.isPlayerWeapon, 10);
		EspVisual(R.id.isLootItems, 11);
		EspVisual(R.id.isPlayerNation, 12);
		EspVisual(R.id.isPlayerTeamID, 13);
		EspVisual(R.id.isVehicles, 14);
		EspVisual(R.id.isHideBot, 15);
		EspVisual(R.id.isItems, 16);
        
        RadioGroup aimgrup = mFloatingView.findViewById(R.id.grupaim);
		aimgrup.setOnCheckedChangeListener((group, checkedId) -> {
			if (checkedId == R.id.disableaim) {
				StopAimBulletFloat();
				StopAimFloat();
				StopAimTouch();
			} else if (checkedId == R.id.aimbot) {
				StartAimFloat();
				StopAimBulletFloat();
				StopAimTouch();
			} else if (checkedId == R.id.bullettrack) {
				StartAimBulletFloat();
				StopAimFloat();
				StopAimTouch();
			}
		});

        final SeekBar rangeSeekBar = mFloatingView.findViewById(R.id.range);
        final TextView rangeText = mFloatingView.findViewById(R.id.rangeText);
        setupSeekBar(rangeSeekBar,rangeText, getrangeAim(), new Runnable() {
            @Override
            public void run() {
                Range(rangeSeekBar.getProgress());
                getrangeAim(rangeSeekBar.getProgress());
            }
        });
        
        final SeekBar distancesSeekBar = mFloatingView.findViewById(R.id.wideview);
        final TextView distancesText = mFloatingView.findViewById(R.id.wideviewtext);
        setupSeekBar(distancesSeekBar, distancesText, getDistances(), new Runnable() {
            @Override
            public void run() {
                WideView(distancesSeekBar.getProgress());
                getwideview(distancesSeekBar.getProgress());
            }
        });
        
        final SeekBar RecoilCompeSeekBar = mFloatingView.findViewById(R.id.AimRecoilCompe);
        final TextView RecoilCompeText = mFloatingView.findViewById(R.id.AimRecoilCompetext);
        setupSeekBar(RecoilCompeSeekBar, RecoilCompeText, getDistances(), new Runnable() {
            @Override
            public void run() {
                recoil(RecoilCompeSeekBar.getProgress());
                getrecoilAim(RecoilCompeSeekBar.getProgress());
            }
        });
        
        final SeekBar wideviewSeekBar = mFloatingView.findViewById(R.id.distances);
        final TextView wideviewText = mFloatingView.findViewById(R.id.distancetext);
        setupSeekBar(wideviewSeekBar, wideviewText, getDistances(), new Runnable() {
            @Override
            public void run() {
                distances(wideviewSeekBar.getProgress());
                setDistances(wideviewSeekBar.getProgress());
            }
        });
        
        final RadioGroup aimby = mFloatingView.findViewById(R.id.aimby);
        aimby.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int chkdId = aimby.getCheckedRadioButtonId();
                RadioButton btn = mFloatingView.findViewById(chkdId);
                AimBy(Integer.parseInt(btn.getTag().toString()));
            }
        });
        
        final RadioGroup aimwhen = mFloatingView.findViewById(R.id.aimwhen);
        aimwhen.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int chkdId = aimwhen.getCheckedRadioButtonId();
                RadioButton btn = mFloatingView.findViewById(chkdId);
                AimWhen(Integer.parseInt(btn.getTag().toString()));
            }
        });
        
        final RadioGroup aimbotmode = mFloatingView.findViewById(R.id.aimbotmode);
        aimbotmode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int chkdId = aimbotmode.getCheckedRadioButtonId();
                RadioButton btn = mFloatingView.findViewById(chkdId);
                Target(Integer.parseInt(btn.getTag().toString()));
            }
        });
        
    }
    
    public native void SettingValue(int setting_code, boolean value);
    public native void SettingMemory(int setting_code, boolean value);
    public native void SettingAim(int setting_code, boolean value);
    public native void RadarSize(int size);
    public native void Range(int range);
    public native void Target(int target);
    public native void AimBy(int aimby);
    public native void AimWhen(int aimwhen);
    public native void distances(int distances);
    public native void WideView(int wideview);
    public native void recoil(int recoil);
}

class SingleTapConfirm extends GestureDetector.SimpleOnGestureListener {
    @Override
    public boolean onSingleTapUp(MotionEvent event) {
        return true;
    }
}

