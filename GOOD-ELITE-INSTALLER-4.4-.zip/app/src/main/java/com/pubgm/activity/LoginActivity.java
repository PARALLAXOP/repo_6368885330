// ---------- LoginActivity.java ----------
package com.pubgm.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.pubgm.Login;
import com.pubgm.R;
import com.pubgm.license.EliteResetPage;
import com.pubgm.utils.ActivityCompat;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class LoginActivity extends ActivityCompat {
    
    private static final String USER = "USER";
    public static String USERKEY;
    
    private CardView btnSignIn;
    private WebView mWebView;
    private TextView versionNameTv;
    private RelativeLayout webViewLayout;
    private EditText textUsername;
    private ImageView showPwd, hidePwd;
    private ImageView pasteBtn;
    private ImageView telegramBtn;
    private LinearLayout layLogin;
    
    // Theme toggle views
    private LinearLayout themeToggle;
    private ImageView iconLight, iconDark;
    
    private EliteResetPage sboxResetPage;
    private MaterialAlertDialogBuilder materialDialogBuilder;
    private Dialog customMaterialDialog;
    
    public static void goLogin(Context context) {
        Intent intent = new Intent(context, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        isLogin = true;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initializeUI();
        loadSavedKey();
        initializeEliteResetPage();
    }
    
    private void initializeUI() {
        layLogin = findViewById(R.id.lay_login);
        btnSignIn = findViewById(R.id.btnSignIn);
        textUsername = findViewById(R.id.textUsername);
        showPwd = findViewById(R.id.show_pwd);
        hidePwd = findViewById(R.id.vis_pwd);
        pasteBtn = findViewById(R.id.paste);
        telegramBtn = findViewById(R.id.telegram_opne);
        versionNameTv = findViewById(R.id.VERSION_NAME);
        webViewLayout = findViewById(R.id.webViewLayout);
        mWebView = findViewById(R.id.activity_main_webview);
        
        // Theme toggle views
        themeToggle = findViewById(R.id.theme_toggle);
        iconLight = findViewById(R.id.icon_light);
        iconDark = findViewById(R.id.icon_dark);
        
        setVersionName();
        setupButtonListeners();
        applyAnimations();
    }
    
    private void setupButtonListeners() {
        btnSignIn.setOnClickListener(v -> handleLoginClick());
        pasteBtn.setOnClickListener(v -> pasteFromClipboard());
        hidePwd.setOnClickListener(v -> togglePasswordVisibility(true));
        showPwd.setOnClickListener(v -> togglePasswordVisibility(false));
        telegramBtn.setOnClickListener(v -> openTelegram());
        findViewById(R.id.ShowWebView).setOnClickListener(v -> showResetLicensePage());
        findViewById(R.id.close_button).setOnClickListener(v -> hideWebView());
        
        // Individual icon clicks
        iconLight.setOnClickListener(v -> themeToggle.performClick());
        iconDark.setOnClickListener(v -> themeToggle.performClick());
    }
    
    private void initializeEliteResetPage() {
        sboxResetPage = new EliteResetPage(this, new EliteResetPage.Callback() {
            @Override
            public void onResetDone(String key) {
                runOnUiThread(() -> {
                    textUsername.setText(key);
                    prefs.write(USER, key);
                    USERKEY = key;
                    showToast("✅ License reset successful!");
                    hideWebView();
                });
            }
            
            @Override
            public void onClose() {
                runOnUiThread(() -> hideWebView());
            }
            
            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    showToast("Error: " + message);
                    showMaterialErrorDialog("Reset Error", message);
                });
            }
        });
    }
    
    private void setVersionName() {
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            versionNameTv.setText("v" + pInfo.versionName);
        } catch (PackageManager.NameNotFoundException e) {
            versionNameTv.setText("v1.0.0");
        }
    }
    
    private void showReset() {
        layLogin.setVisibility(View.GONE);
        webViewLayout.setVisibility(View.VISIBLE);
        sboxResetPage.open(textUsername.getText().toString());
    }

    private void hideReset() {
        webViewLayout.setVisibility(View.GONE);
        layLogin.setVisibility(View.VISIBLE);
    }
    
    private void applyAnimations() {
        try {
            LinearLayout loginLayout = findViewById(R.id.loginbtn);
            if (loginLayout != null) {
                Animation slideUp = AnimationUtils.loadAnimation(this, R.anim.slide_up);
                loginLayout.startAnimation(slideUp);
            }
            
            LinearLayout inputLayout = findViewById(R.id.animeson_enter_key);
            if (inputLayout != null) {
                Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
                inputLayout.startAnimation(fadeIn);
            }
            
            ImageView logo = findViewById(R.id.jkpapa_ka_loda);
            if (logo != null) {
                Animation scaleIn = AnimationUtils.loadAnimation(this, R.anim.scale_in);
                logo.startAnimation(scaleIn);
            }
        } catch (Exception e) {
            // Ignore animation errors
        }
    }
    
    private void loadSavedKey() {
        String savedKey = prefs.read(USER, "");
        if (!savedKey.isEmpty()) {
            textUsername.setText(savedKey);
        }
    }
    
    private void handleLoginClick() {
        String userKey = textUsername.getText().toString().trim();
        if (userKey.isEmpty()) {
            textUsername.setError("Please enter license key");
            showToast("Please enter license key");
            return;
        }
        
        prefs.write(USER, userKey);
        USERKEY = userKey;
        Login(this, userKey);
    }
    
    private void pasteFromClipboard() {
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard.hasPrimaryClip()) {
                String copiedText = clipboard.getPrimaryClip().getItemAt(0).getText().toString();
                textUsername.setText(copiedText);
                showToast("Key pasted");
            } else {
                showToast("Clipboard is empty");
            }
        } catch (Exception e) {
            showToast("Failed to paste");
        }
    }
    
    private void togglePasswordVisibility(boolean show) {
        if (show) {
            textUsername.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            showPwd.setVisibility(View.VISIBLE);
            hidePwd.setVisibility(View.GONE);
        } else {
            textUsername.setTransformationMethod(PasswordTransformationMethod.getInstance());
            showPwd.setVisibility(View.GONE);
            hidePwd.setVisibility(View.VISIBLE);
        }
        textUsername.setSelection(textUsername.getText().length());
    }
    
    private void openTelegram() {
        try {
            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/+oD2Z0F44Y5QxN2Q1")));
        } catch (Exception e) {
            showToast("Cannot open Telegram");
        }
    }
    
    private void showResetLicensePage() {
        layLogin.setVisibility(View.GONE);
        webViewLayout.setVisibility(View.VISIBLE);
        String currentKey = textUsername.getText().toString().trim();
        sboxResetPage.open(currentKey);
    }
    
    private void hideWebView() {
        webViewLayout.setVisibility(View.GONE);
        layLogin.setVisibility(View.VISIBLE);
        mWebView.loadUrl("about:blank");
    }
    
    // ============= MATERIAL DIALOG METHODS (Only for errors) =============
    
    private void showMaterialErrorDialog(String errorMessage) {
        dismissMaterialDialog();
        
        // Inflate custom layout
        LayoutInflater inflater = LayoutInflater.from(this);
        View customView = inflater.inflate(R.layout.dialog_progress, null);
        
        // Hide progress indicator
        CircularProgressIndicator progressBar = customView.findViewById(R.id.progress_circular);
        if (progressBar != null) {
            progressBar.setVisibility(View.GONE);
        }
        
        // Format and show error message
        TextView progressText = customView.findViewById(R.id.progress_text);
        if (progressText != null) {
            progressText.setTextColor(Color.parseColor("#FF4444")); // Red color
            progressText.setText(formatErrorMessage(errorMessage));
        }
        
        // Create MaterialAlertDialogBuilder
        materialDialogBuilder = new MaterialAlertDialogBuilder(this);
        materialDialogBuilder.setView(customView);
        materialDialogBuilder.setCancelable(true);
        
        // Add OK button
        materialDialogBuilder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        
        customMaterialDialog = materialDialogBuilder.show();
        
        // Make background transparent
        if (customMaterialDialog.getWindow() != null) {
            customMaterialDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }
    
    private void showMaterialErrorDialog(String title, String errorMessage) {
        dismissMaterialDialog();
        
        LayoutInflater inflater = LayoutInflater.from(this);
        View customView = inflater.inflate(R.layout.dialog_progress, null);
        
        CircularProgressIndicator progressBar = customView.findViewById(R.id.progress_circular);
        if (progressBar != null) {
            progressBar.setVisibility(View.GONE);
        }
        
        TextView progressText = customView.findViewById(R.id.progress_text);
        if (progressText != null) {
            progressText.setTextColor(Color.parseColor("#FF4444"));
            progressText.setText(errorMessage);
        }
        
        materialDialogBuilder = new MaterialAlertDialogBuilder(this);
        materialDialogBuilder.setTitle(title);
        materialDialogBuilder.setView(customView);
        materialDialogBuilder.setCancelable(true);
        materialDialogBuilder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        
        customMaterialDialog = materialDialogBuilder.show();
        
        if (customMaterialDialog.getWindow() != null) {
            customMaterialDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }
    
    private String formatErrorMessage(String errorMessage) {
        if (errorMessage.equals("User Or Game Not Registered")) {
            return getString(R.string.userorgamenotregis) + "\n\n" + errorMessage;
        } else if (errorMessage.equals("Expired Key...")) {
            return getString(R.string.expiredkey) + "\n\n" + errorMessage;
        } else if (errorMessage.equals("Max Device Reached")) {
            return getString(R.string.maxdevice) + "\n\n" + errorMessage;
        } else if (errorMessage.equals("Bad Parameter")) {
            return getString(R.string.BadParameter) + "\n\n" + errorMessage;
        } else if (errorMessage.equals("Cheat Under Maintenance")) {
            return getString(R.string.MAINTENANCE) + "\n\n" + errorMessage;
        } else if (errorMessage.equals("Invalid Parameter")) {
            return getString(R.string.INVALIDPARAMETER) + "\n\n" + errorMessage;
        } else if (errorMessage.equals("User Blocked")) {
            return getString(R.string.userblock) + "\n\n" + errorMessage;
        } else {
            return errorMessage;
        }
    }
    
    private void dismissMaterialDialog() {
        if (customMaterialDialog != null && customMaterialDialog.isShowing()) {
            customMaterialDialog.dismiss();
        }
    }
    
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    
    // ============= LOGIN METHOD =============
    
    private static void Login(final LoginActivity m_Context, final String userKey) {
        final ProgressDialog progressDialog = new ProgressDialog(m_Context, 5);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        
        final Handler loginHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    MainActivity.goMain(m_Context);
                    m_Context.toast("Login Success");
                    m_Context.finishActivity(0);
                } else if (msg.what == 1) {
                    m_Context.showMaterialErrorDialog(msg.obj.toString());
                    m_Context.toast("Login Failed");
                }
                progressDialog.dismiss();
            }
        };

        new Thread(() -> {
            if (m_Context.isFinishing()) return;
            
            try {
                String result = Login.check(m_Context, userKey);
                
                if (result.equals("OK")) {
                    loginHandler.sendEmptyMessage(0);
                } else {
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = result;
                    loginHandler.sendMessage(msg);
                }
            } catch (Exception e) {
                Message msg = new Message();
                msg.what = 1;
                msg.obj = "Login check failed";
                loginHandler.sendMessage(msg);
            }
        }).start();
    }
    
    @Override
    public void onBackPressed() {
        if (webViewLayout.getVisibility() == View.VISIBLE){
            hideReset();
        }else{
            super.onBackPressed();
        }
    }
}