package com.pubgm.activity;

import android.app.ActivityManager;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.pubgm.Config;
import com.pubgm.Login;
import com.pubgm.R;
import com.pubgm.adapter.RecyclerViewAdapter;
import com.pubgm.floating.FloatLogo;
import com.pubgm.floating.Overlay;
import com.pubgm.libhelper.DownloadZip;
import com.pubgm.utils.ActivityCompat;
import com.pubgm.utils.Shell;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import static com.pubgm.Config.GAME_LIST_ICON;
import static com.pubgm.Config.GAME_LIST_PKG;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class MainActivity extends ActivityCompat {
    
    public static MainActivity instance;
    private String daemonPath;
    public static String socket;
    public String CURRENT_PACKAGE = "";
    private LinearProgressIndicator progress;
    private RecyclerView recyclerView;
    private RecyclerViewAdapter adapter;
    String sFixCrash = Login.FixCrash();

    private Dialog verifyDialog;
    private View progressBarView;
    private TextView tvStatusText, tvStatusDetail, tvKeyText, tvErrorMessage;
    private LinearLayout progressContainer, statusContainer, deviceInfoContainer, keyContainer, successScreen, errorScreen;
    private TextView tvDeviceInfo, tvAndroidInfo, tvSDKInfo;
    private boolean verified = false;
    private Handler handler = new Handler(Looper.getMainLooper());
    
    // ORIGINAL BGMI METHOD - 100% UNCHANGED
    public void doInitRecycler() {
		progress.setVisibility(View.VISIBLE);
		handler.postDelayed(() -> {

			ArrayList<Integer> imageValues = new ArrayList<>();
			ArrayList<String> titleValues = new ArrayList<>();
			ArrayList<String> versionValues = new ArrayList<>();
			ArrayList<String> statusValues = new ArrayList<>();
			ArrayList<String> packageValues = new ArrayList<>();
			ArrayList<String> genreValues = new ArrayList<>();
			ArrayList<String> regionValues = new ArrayList<>();

			// Assets folder se JSON read karo
			String jsonString = loadJson("games.json");

			try {
				JSONArray jsonArray = new JSONArray(jsonString);
				for (int i = 0; i < jsonArray.length(); i++) {
					JSONObject game = jsonArray.getJSONObject(i);
					// JSON se data nikal ke lists mein dalo
					imageValues.add(GAME_LIST_ICON[game.getInt("imageIndex")]);
					titleValues.add(game.getString("title"));
					versionValues.add(game.getString("version"));
					statusValues.add(game.getString("status"));
					packageValues.add(game.getString("package"));
					genreValues.add(game.getString("genre"));
					regionValues.add(game.getString("region"));
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
			adapter = new RecyclerViewAdapter(this, imageValues, titleValues, versionValues, statusValues, packageValues, genreValues, regionValues);
			recyclerView.setAdapter(adapter);
			progress.setVisibility(View.GONE);

		}, 300);
	}
    
	public String loadJson(String fileName) {
		String json = null;

		// 1️⃣ Try Internal Storage (getFilesDir)
		try {
			File file = new File(getFilesDir(), fileName);
			if (file.exists()) {
				FileInputStream fis = new FileInputStream(file);
				int size = fis.available();
				byte[] buffer = new byte[size];
				fis.read(buffer);
				fis.close();
				return new String(buffer, "UTF-8");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// 2️⃣ Try External App Storage (getExternalFilesDir)
		try {
			File file = new File(getExternalFilesDir(null), fileName);
			if (file.exists()) {
				FileInputStream fis = new FileInputStream(file);
				int size = fis.available();
				byte[] buffer = new byte[size];
				fis.read(buffer);
				fis.close();
				return new String(buffer, "UTF-8");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// 3️⃣ Try Assets
		try {
			InputStream is = getAssets().open(fileName);
			int size = is.available();
			byte[] buffer = new byte[size];
			is.read(buffer);
			is.close();
			json = new String(buffer, "UTF-8");
		} catch (IOException ex) {
			ex.printStackTrace();
			return null;
		}

		return json;
	}
    
    // ORIGINAL LOAD ASSETS METHOD - 100% UNCHANGED
    public void loadAssets() {
        String filepath = Environment.getExternalStorageDirectory() + "/Android/data/.tyb";
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(filepath);
            byte[] buffer = "DO NOT DELETE".getBytes();
            fos.write(buffer, 0, buffer.length);
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        daemonPath = getFilesDir().toString() + "/sock64";
        if (Shell.rootAccess()) {
            socket = "su -c " + daemonPath;
        } else {
            socket = daemonPath;
        }
        try {
            Runtime.getRuntime().exec("chmod 777 " + daemonPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static MainActivity get() {
        return instance;
    }
    
    public static void goMain(Context context) {
        Intent i = new Intent(context, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(i);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        setContentView(R.layout.activity_main);
        progress = findViewById(R.id.progress);
        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recyclerView.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        hideSystemUI();
        
        View searchBox = findViewById(R.id.searchBox);
        if (searchBox != null) {
            searchBox.setOnClickListener(v -> {
               // ToastUtils.showShort("Search functionality coming soon!");
            });
        }
        
        View profileContainer = findViewById(R.id.profileContainer);
        if (profileContainer != null) {
            profileContainer.setOnClickListener(v -> {
               startActivity(new Intent(MainActivity.this, ProfileActivity.class));
            });
        }
        
        // CHECK VERIFICATION STATUS
        SharedPreferences prefs = getSharedPreferences("auth_pref", MODE_PRIVATE);
        boolean isVerified = prefs.getBoolean("verified", false);
        long expiry = prefs.getLong("expiry", 0);
        
        if (isVerified && expiry > System.currentTimeMillis()/1000) {
            verified = true;
            recyclerView.setVisibility(View.VISIBLE);
//            if (sFixCrash != null && !sFixCrash.isEmpty())
//                new DownloadZip(this).startDownload(sFixCrash);
            doInitRecycler(); // ORIGINAL METHOD CALLED
        } else {
            createVerifyDialog();
        }
        
        

        
    }

    private void createVerifyDialog() {
        verifyDialog = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar);
        verifyDialog.setCancelable(false);
        
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_verify, null);
        verifyDialog.setContentView(dialogView);
        
        progressBarView = dialogView.findViewById(R.id.progressBar);
        tvStatusText = dialogView.findViewById(R.id.tvStatusText);
        tvStatusDetail = dialogView.findViewById(R.id.tvStatusDetail);
        tvKeyText = dialogView.findViewById(R.id.tvKeyText);
        tvErrorMessage = dialogView.findViewById(R.id.tvErrorMessage);
        
        progressContainer = dialogView.findViewById(R.id.progressContainer);
        statusContainer = dialogView.findViewById(R.id.statusContainer);
        deviceInfoContainer = dialogView.findViewById(R.id.deviceInfoContainer);
        keyContainer = dialogView.findViewById(R.id.keyContainer);
        successScreen = dialogView.findViewById(R.id.successScreen);
        errorScreen = dialogView.findViewById(R.id.errorScreen);
        
        tvDeviceInfo = dialogView.findViewById(R.id.tvDeviceInfo);
        tvAndroidInfo = dialogView.findViewById(R.id.tvAndroidInfo);
        tvSDKInfo = dialogView.findViewById(R.id.tvSDKInfo);
        
        // MEDIUM SIZE DIALOG
        Window window = verifyDialog.getWindow();
        if (window != null) {
            window.setLayout(dp(180), dp(220));  // Width: 180dp, Height: 220dp
            window.setGravity(Gravity.CENTER);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        
        verifyDialog.show();
        startVerification();
    }
    
    private void startVerification() {
        tvStatusText.setText("VERIFYING");
        tvStatusDetail.setText("Please wait...");
        loadDeviceInfo();
        
        String key = getUserKey();
        tvKeyText.setText(key);
        
        if (key == null || key.equals("INVALID") || key.equals("null") || key.trim().isEmpty()) {
            showError("INVALID LICENCE KEY");
            return;
        }
        
        new Thread(() -> {
            try {
                String result = Login.check(MainActivity.this, key);
                runOnUiThread(() -> {
                    if (result.equals("OK")) {
                        // SAVE VERIFICATION STATE
                        SharedPreferences prefs = getSharedPreferences("auth_pref", MODE_PRIVATE);
                        prefs.edit().putBoolean("verified", true).putLong("expiry", (System.currentTimeMillis()/1000) + 86400).apply();
                        tvStatusText.setText("VERIFIED");
                        tvStatusDetail.setText("Licence confirmed");
                        handler.postDelayed(() -> {
                            progressContainer.setVisibility(View.GONE);
                            statusContainer.setVisibility(View.GONE);
                            deviceInfoContainer.setVisibility(View.GONE);
                            keyContainer.setVisibility(View.GONE);
                            successScreen.setVisibility(View.VISIBLE);
                            handler.postDelayed(() -> {
                                verifyDialog.dismiss();
                                onVerified();
                            }, 800);
                        }, 500);
                    } else {
                        showError(result);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> showError(e.getMessage()));
            }
        }).start();
    }
    
    private void onVerified() {
        if (verified) return;
        verified = true;
        
        recyclerView.setVisibility(View.VISIBLE);
//        if (sFixCrash != null && !sFixCrash.isEmpty())
//            new DownloadZip(this).startDownload(sFixCrash);
        
        doInitRecycler(); // ORIGINAL METHOD CALLED
    }
    
    private void showError(String message) {
        runOnUiThread(() -> {
            progressContainer.setVisibility(View.GONE);
            statusContainer.setVisibility(View.GONE);
            deviceInfoContainer.setVisibility(View.GONE);
            keyContainer.setVisibility(View.GONE);
            tvErrorMessage.setText(message);
            errorScreen.setVisibility(View.VISIBLE);
            handler.postDelayed(() -> {
                verifyDialog.dismiss();
                MainActivity.this.toast("Licence Error: " + message);
                LoginActivity.goLogin(MainActivity.this);
                finish();
            }, 2000);
        });
    }
    
    private void loadDeviceInfo() {
        runOnUiThread(() -> {
            tvDeviceInfo.setText("Device: " + getDeviceName());
            tvAndroidInfo.setText("Android: " + getAndroidVersion());
            tvSDKInfo.setText("SDK: " + getSDKVersion());
        });
    }
    
    private String getUserKey() {
        if (LoginActivity.USERKEY != null && !LoginActivity.USERKEY.isEmpty()) {
            return LoginActivity.USERKEY;
        }
        return "INVALID";
    }
    
    private String getDeviceName() {
        return Build.MANUFACTURER + " " + Build.MODEL;
    }
    
    private String getAndroidVersion() {
        return Build.VERSION.RELEASE;
    }
    
    private String getSDKVersion() {
        return String.valueOf(Build.VERSION.SDK_INT);
    }
    
    private int dp(int d) {
        return Math.round(d * getResources().getDisplayMetrics().density);
    }

    public LinearProgressIndicator getProgresBar() {
        return progress;
    }
    
    public void doShowProgress(boolean indeterminate) {
        if (progress == null) return;
        runOnUiThread(() -> {
            progress.setVisibility(View.VISIBLE);
            progress.setIndeterminate(indeterminate);
        });
    }
    
    public void doHideProgress() {
        if (progress == null) return;
        runOnUiThread(() -> {
            progress.setVisibility(View.GONE);
        });
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }
    
    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (FloatLogo.class.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    public void startPatcher() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 123);
            } else {
                startService(new Intent(MainActivity.get(), FloatLogo.class));
                loadAssets(); // ORIGINAL METHOD CALLED
            }
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        if (verifyDialog != null && verifyDialog.isShowing()) {
            verifyDialog.dismiss();
        }
    }
}